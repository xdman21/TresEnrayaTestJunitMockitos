/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg3_en_raya;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.junit.Test;
import static org.mockito.Mockito.when;
/**
 *
 * @author xavi
 */

public class Main 
{
    @Test
    public static void main(String[] args) throws IOException
    {
        BufferedReader bufferedReader = org.mockito.Mockito.mock(BufferedReader.class);
        when(bufferedReader.readLine()).thenReturn("hola").thenReturn("adeu");
        
        int i = 1;
        
        System.out.println("Escribe nombre Jugador1");
        String nombrejugador1 = bufferedReader.readLine();
        System.out.println(nombrejugador1);
        
        System.out.println("Escribe Nombre Jugador 2");
        String nombrejugador2 = bufferedReader.readLine();
        System.out.println(nombrejugador2);
        
        tablero t = new tablero();

        t.crearTablero();
        t.imprimirtablero();
        boolean error = true;
        while(i != 10) 
        {
            error = true;
            while(error == true) 
            {
            try 
            {
                t.moverjugador1();
                error = false;
            } 
            catch (lessthanex ex) 
            {
                System.out.println("ERROR");
            }
            }
            System.out.println(t.wincheck());
            if(t.wincheck().equals("GANO EL JUGADOR 1")) 
            {
                System.out.println("Tablero Reseteado");
                t.crearTablero();
            }
            error = true;
            while(error == true) 
            {
            try 
            {
                t.moverjugador2();
                error = false;
            } 
            catch (lessthanex ex) 
            {
                System.out.println("ERROR");
            }
            }
            System.out.println(t.wincheck());
            if(t.wincheck().equals("GANO EL JUGADOR 2")) 
            {
                System.out.println("Tablero Reseteado");
                t.crearTablero();
            }
            
            i++;
            } 
        try 
        {
            t.moverjugador1();
        } catch (lessthanex ex) 
        {
            System.out.println("ERROR");
        }
    }
}
